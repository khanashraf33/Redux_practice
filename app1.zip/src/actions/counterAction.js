export const increament = () => {
    return {
        type: 'increament',
    }
}

export const decrement = () => {
    return {
        type: 'decrement',
    }
}

export const reset = () => {
    return {
        type: 'reset',
    }
}

