
import Header from './../components/Header';
const AboutScreen = (props) => {

    return (
        <div>
            <Header title="About"/>
        </div>
    )
}

export default AboutScreen