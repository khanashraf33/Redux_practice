import Header from "../components/Header"

const LoginScreen = (props) => {
    return (
        <div>
            <Header title="Login"/>
        </div>
    )
}

export default LoginScreen