import Header from './../components/Header';
const HomeScreen = (props) => {

    return (
        <div>
            <Header title="Home"/>
        </div>
    )
}

export default HomeScreen