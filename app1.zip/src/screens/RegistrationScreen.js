import Header from "../components/Header"

const RegistrationScreen = (props) => {
    return (
        <div>
            <Header title="Signup"/>
        </div>
    )
}

export default RegistrationScreen